# Mike's Chat Cards

A module to alter the base chat cards. This will color the cards based on the player who added the chat entry.

A fork of DeepFlame's Chat Cards to update to FoundryVTT v10.